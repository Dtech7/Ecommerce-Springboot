export const sliderProducts = [
    {
        id: 1,
        img: "https://images.unsplash.com/photo-1623288516140-47a0a17cec7c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=760&q=80",
        title: "SUMMER SALE",
        desc: "GET ALL SUMMER ITEMS ON SALE",
        bg: "fce1e4",
    },
    {
        id: 2,
        img: "https://images.unsplash.com/photo-1603217192097-13c306522271?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80",
        title: "SPRING SALE",
        desc: "GET ALL SPRING ITEMS ON SALE",
        bg: "e1fcce",
    },
    {
        id: 3,
        img: "https://images.unsplash.com/photo-1614093326149-fcc8e0783caf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=774&q=80",
        title: "WINTER SALE",
        desc: "GET ALL WINTER ITEMS ON SALE",
        bg: "e1f2fc",
    },
    {
        id: 4,
        img: "https://images.unsplash.com/photo-1530710443108-9a29d6a82ee7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=774&q=80",
        title: "FALL SALE",
        desc: "GET ALL FALL ITEMS ON SALE",
        bg: "fcece1",
    },
]
