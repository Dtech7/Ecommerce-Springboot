export const products = [
    {
        productId: 1,
        img: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=776&q=80",
        title: "Button Up Shirt",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 2,
        img: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=764&q=80",
        title: "T Shirt",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 3,
        img: "https://cdni.llbean.net/is/image/wim/301128_1498_41?hei=1095&wid=950&resMode=sharp2&defaultImage=llbprod/A0211793_2",
        title: "Jeans",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 4,
        img: "https://www.ortery.com/wp-content/uploads/2019/01/dress-on-blue-bkg.png",
        title: "Dress",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 5,
        img: "https://www.rlmedia.io/is/image/PoloGSI/s7-1173581_lifestyle?$rl_df_pdp_5_7_lif$",
        title: "Socks",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 6,
        img: "https://images.unsplash.com/photo-1584030373081-f37b7bb4fa8e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=691&q=80",
        title: "Blouse",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 7,
        img: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=776&q=80",
        title: "Button Up Shirt",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 8,
        img: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=764&q=80",
        title: "T Shirt",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 9,
        img: "https://cdni.llbean.net/is/image/wim/301128_1498_41?hei=1095&wid=950&resMode=sharp2&defaultImage=llbprod/A0211793_2",
        title: "Jeans",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 10,
        img: "https://www.ortery.com/wp-content/uploads/2019/01/dress-on-blue-bkg.png",
        title: "Dress",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 11,
        img: "https://www.rlmedia.io/is/image/PoloGSI/s7-1173581_lifestyle?$rl_df_pdp_5_7_lif$",
        title: "Socks",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 12,
        img: "https://images.unsplash.com/photo-1584030373081-f37b7bb4fa8e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=691&q=80",
        title: "Blouse",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 13,
        img: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=776&q=80",
        title: "Button Up Shirt",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 14,
        img: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=764&q=80",
        title: "T Shirt",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 15,
        img: "https://cdni.llbean.net/is/image/wim/301128_1498_41?hei=1095&wid=950&resMode=sharp2&defaultImage=llbprod/A0211793_2",
        title: "Jeans",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 16,
        img: "https://www.ortery.com/wp-content/uploads/2019/01/dress-on-blue-bkg.png",
        title: "Dress",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 17,
        img: "https://www.rlmedia.io/is/image/PoloGSI/s7-1173581_lifestyle?$rl_df_pdp_5_7_lif$",
        title: "Socks",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
    {
        productId: 18,
        img: "https://images.unsplash.com/photo-1584030373081-f37b7bb4fa8e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=691&q=80",
        title: "Blouse",
        desc: "Lorem ipsum dolor sit amet, qui minim labore adipisicing minim sint cillum sint consectetur cupidatat.",
        price: Math.floor(Math.random() * 100)
    },
]
