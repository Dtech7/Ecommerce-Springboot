export const receipts = [
    {
        items: [{
            title: "Button Up Shirt",
            amount: 5,
            price: 36,
        }, {
            title: "Jeans",
            amount: 5,
            price: 57,
        }, {
            title: "Socks",
            amount: 5,
            price: 12,
        }],
        userId: 1,
        receiptId: 1,
        date: "03-30-2022"
    },
    {
        items: [{
            title: "Button Up Shirt",
            amount: 5,
            price: 36,
        }, {
            title: "Jeans",
            amount: 5,
            price: 57,
        }, {
            title: "Socks",
            amount: 5,
            price: 12,
        }],
        userId: 1,
        receiptId: 2,
        date: "09-05-2022"
    },
    {
        items: [{
            title: "Button Up Shirt",
            amount: 5,
            price: 36,
        }, {
            title: "Jeans",
            amount: 5,
            price: 57,
        }, {
            title: "Socks",
            amount: 5,
            price: 12,
        }],
        userId: 1,
        receiptId: 3,
        date: "12-22-2022"
    },
]
