import React from 'react'

const FooterBanner = () => {
    return (
        <div>FooterBanner</div>
    )
}

export default FooterBanner
