export const user = {
    id: 1,
    firstName: "Joshua",
    lastName: "Maciel",
    email: "josh@mail.com",
    phoneNumber: "888-888-8888",
    address: "123 some street",
    password: "password"
}
